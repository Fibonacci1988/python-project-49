# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Fibonacci1988/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Fibonacci1988/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/Fibonacci1988/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/44a9fdd87f6156fb3529/maintainability" /></a>\n\nAsciinema video on how to publish and demo of brain-even game: https://asciinema.org/a/jbYF7BlxXyUEyt5gTEimrdfDP\n\nAsciinema video demo of brain-calc game: https://asciinema.org/a/Ugh35ZnYNCXbWfXn9wHrSY9iX\n\nAsciinema video demo of brain-gcd game: https://asciinema.org/a/nM8m4dAcn1yWslKY1f1gjrlup\n\nAsciinema video demo of brain-progression game: https://asciinema.org/a/fr6ozhpDlIj6pDNegHTT3swC7\n\nAsciinema video demo of brain-prime game: https://asciinema.org/a/gtyUVj3kBMcV39LbcbxPRtLlz\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9.12,<4.0.0',
}


setup(**setup_kwargs)
