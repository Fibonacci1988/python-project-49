### Hexlet tests and linter status:
[![Actions Status](https://github.com/Fibonacci1988/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Fibonacci1988/python-project-49/actions)

<a href="https://codeclimate.com/github/Fibonacci1988/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/44a9fdd87f6156fb3529/maintainability" /></a>

Asciinema video on how to publish and demo of brain-even game: https://asciinema.org/a/jbYF7BlxXyUEyt5gTEimrdfDP

Asciinema video demo of brain-calc game: https://asciinema.org/a/Ugh35ZnYNCXbWfXn9wHrSY9iX

Asciinema video demo of brain-gcd game: https://asciinema.org/a/nM8m4dAcn1yWslKY1f1gjrlup

Asciinema video demo of brain-progression game: https://asciinema.org/a/fr6ozhpDlIj6pDNegHTT3swC7

Asciinema video demo of brain-prime game: https://asciinema.org/a/gtyUVj3kBMcV39LbcbxPRtLlz
